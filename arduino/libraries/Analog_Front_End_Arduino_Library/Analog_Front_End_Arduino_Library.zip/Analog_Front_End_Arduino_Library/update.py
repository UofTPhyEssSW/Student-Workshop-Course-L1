import os
import shutil
from os import path
from zipfile import ZipFile
from shutil import make_archive

def update_library():
    print("Running AFE Shield library update.")

update_library()
