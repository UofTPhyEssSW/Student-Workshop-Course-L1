import os
import shutil
from os import path
from zipfile import ZipFile
from shutil import make_archive

def update_library():
    print("Running Phyduino Pico update.")

update_library()
